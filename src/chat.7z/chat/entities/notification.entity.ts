export type NotifPayLoad = {
    staff__id?: string;
    rol?: string[]
    socket_id: string;
}