import {
  // OnGatewayConnection, OnGatewayDisconnect, OnGatewayInit,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
// import { NotifPayLoad } from './entities/notification.entity';
import { InMemoryDBEntity, InMemoryDBService } from '@nestjs-addons/in-memory-db';

export interface NotifPayLoad extends InMemoryDBEntity {
  id: string; // el mismo socket_id
  staff__id?: string;
  rol?: string[]
  // socket_id: string;
}

export enum DbState {
  insert = 'insert',
  update = 'update',
  select = 'select',
  delete = 'delete',
  none = 'none'
}

export interface CollectionNotification {
  dbState: DbState;
  collection?: string; // PollGroups, PollResult, ...
  field_id?: string; /// _id de el elemento en la colección
  // fieldId?: string; /// id de el elemento en la colección
  user_id?: string; // _id del origen del cambio
  usert_id?: string; // nombre del origen del cambio
  date?: number; // Fecha de la actualización
  data?: any;
  OriginalsocketId: string;
}

// @WebSocketGateway(Number(process.env.CHAT_PORT), { cors: { origin: '*' } })
@WebSocketGateway()
export class ChatGateway {

  constructor(private readonly notifData: InMemoryDBService<NotifPayLoad>) {

  }

  @WebSocketServer() server: Server;

  

  // ................... MEMORY DATA BASE MEMORY DATA BASE MEMORY DATA BASE .....................

  async getAll() {
    return await this.notifData.getAll();
  }

  async getById(socket_id: string) {
    return await this.notifData.get(socket_id);
  }

  async getByUser(staff__id: string) {
    return await this.notifData.queryAsync(nd => nd.staff__id == staff__id);
  }

  async upSert(updateCard: any) {
    this.notifData.updateAsync(updateCard);
  }

  async delete(id: string) {
    this.notifData.deleteAsync(id);
  }

  // ...........................................................................................

  handleConnection(client: any, ...args: any[]) {
    console.log(args);
    const updateCard: NotifPayLoad = {
      id: client.id
    }
    this.upSert(updateCard);
    console.log('Hola alguien se conecto al socket', client.id);
  }

  @SubscribeMessage('credential')
  handleCredential(client: Socket, data: any) {
    const updateCard: NotifPayLoad = {
      staff__id: data.staff__id,
      id: client.id,
      rol: data.rol.split(',')
    }
    this.upSert(updateCard)
  }

  handleDisconnect(client: any) {
    this.delete(client.id)
    // console.log('ALguien se fue', client.id)
  }

  /*
  @SubscribeMessage('event_join')
  handleJoinRoom(client: Socket, room: string) {
    client.join(`room_${room}`);
  }

  @SubscribeMessage('event_message') //TODO Backend
  handleIncommingMessage(
    client: Socket,
    payload: { room: string; message: string },
  ) {
    const { room, message } = payload;
    console.log(payload)
    this.server.to(`room_${room}`).emit('new_message', message);
  }

  @SubscribeMessage('event_leave')
  handleRoomLeave(client: Socket, room: string) {
    console.log(`chao room_${room}`)
    client.leave(`room_${room}`);
  }
  */

  // ..............................................................................................

  async handleNotifCMD(
    dbState: DbState,
    collection: string,
    field_id: string,
    user_id: string,
    usert_id: string, // Staff a quien se dirige la accion, if _broadcast_ a todos
    data: any
  ) {
    // Get list of subscriber clients
    const soketList = await this.getAll();
    // TODO: TEMPORAL
    // soketList = this.getAllSocketId()
    const actualClient = await this.getById(user_id);
    /*
    soketList = this.getByPollResult(pollResult_id);
    soketList = [...soketList, ...this.getByPollsGroup(pollGrp_id)];
    */

    soketList.forEach(sklist => {

      if (sklist.rol.includes('P') || usert_id === '_broadcast_' || actualClient.staff__id === usert_id)
      {
        const payload: CollectionNotification = {
          dbState, collection, field_id, user_id, usert_id,
          date: Date.now(),
          data,
          OriginalsocketId: actualClient.id
        }
        this.server.emit('dtb-notification', payload);
      }
      
    });
  }

  // ............................................................................................

}

/*
  // ................... MEMORY DATA BASE MEMORY DATA BASE MEMORY DATA BASE .....................
  private notification: Array<NotifPayLoad> = [];
  getAllSocketId(): Array<string> {
    const result: string[] = [];
    this.notification.forEach((notif) => result.push(notif.socket_id));
    return result;
  }

  getAll(): Array<NotifPayLoad> {
    return this.notification;
  }

  getById(staff__id: string): NotifPayLoad {
    return this.notification.find((notif) => notif.staff__id === staff__id);
  }

  upCreated(idsocket_id: string, updateCard: any) {
    const indexToUpdate = this.notification.findIndex((notif) => notif.socket_id === idsocket_id);
    if (indexToUpdate >= 0) {
      this.notification[indexToUpdate] = {
        ...this.notification[indexToUpdate],
        ...updateCard,
      };
    } else {
      /// updateCard.id = Date.now();
      this.notification.push(updateCard);
    }
  }

  create(notif: any) {
    notif.id = Date.now();
    notif.validDate = new Date().toLocaleDateString('ES');
    this.notification = [...this.notification, notif];
  }

  update(staff__id: string, updateCard: any) {
    const indexToUpdate = this.notification.findIndex((notif) => notif.staff__id === staff__id);

    if (indexToUpdate >= 0) {
      this.notification[indexToUpdate] = {
        ...this.notification[indexToUpdate],
        ...updateCard,
      };
    }
  }

  delete(socket_id: string) {
    const cardIndex = this.notification.findIndex((c) => c.socket_id === socket_id);
    if (cardIndex >= 0) {
      this.notification.splice(cardIndex, 1);
    }
  }
  */

// .............................................................

/*
afterInit(server: any) {
  console.log('Esto se ejecuta cuando inicia')
}
*/